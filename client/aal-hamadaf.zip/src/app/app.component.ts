import { Component } from '@angular/core';
import {SortService} from './services/sort.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
    fixed;
    constructor(public sort: SortService) {
        this.fixed = window.pageYOffset > 200;
    }
    updateFixed() {
        this.fixed = window.pageYOffset > 200;
    }


}
