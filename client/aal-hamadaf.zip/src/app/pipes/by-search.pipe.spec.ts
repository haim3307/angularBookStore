import { BySearchPipe } from './by-search.pipe';

describe('BySearchPipe', () => {
  it('create an instance', () => {
    const pipe = new BySearchPipe();
    expect(pipe).toBeTruthy();
  });
});
