import { ByYearPipe } from './by-year.pipe';

describe('ByYearPipe', () => {
  it('create an instance', () => {
    const pipe = new ByYearPipe();
    expect(pipe).toBeTruthy();
  });
});
