import { Component, OnInit, Input } from '@angular/core';
import {SortService} from '../../services/sort.service';
import {MainData} from '../../services/main-data';

@Component({
    selector: 'app-sort-nav',
    templateUrl: './sort-nav.component.html',
    styleUrls: ['./sort-nav.component.css']
})
export class SortNavComponent implements OnInit {
    window = window;
    @Input('mode') mode;
    @Input('storeMode') storeMode = false;
    constructor(public sort: SortService, public listsSer: MainData) {}
    ngOnInit() {  }
    update() {
        console.log('hi');
    }
}
