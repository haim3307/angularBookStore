import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class JsonReqsService {

  constructor(private $http: HttpClient) { }
  booksHttpReq() {
      return this.$http.get('assets/json/books.json');
  }
  getAuthorsDet() {
      return this.$http.get('assets/json/authors.json');
  }
}
