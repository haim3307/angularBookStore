import { Component, OnInit } from '@angular/core';
import {MainData} from '../../services/main-data';
import {SortService} from '../../services/sort.service';

@Component({
  selector: 'app-store-page',
  templateUrl: './store-page.component.html',
  styleUrls: ['./store-page.component.css']
})
export class StorePageComponent implements OnInit {
    window = window;
    heLetters = 'אבגדהוזחטיכלמנסעפצקרשת'.split('');
  constructor(public listsSer: MainData, public sort: SortService) {
    if (this.listsSer.books.length === 0) listsSer.booksPreview();
    this.window.addEventListener('resize', () => {
        this.changeGrid();
    });
    this.changeGrid();
    console.log(this.heLetters);

  }
  changeGrid() {
      if(this.window.innerWidth > 1600) this.sort.gridWeb = 4;
      if(this.window.innerWidth > 1350 && this.window.innerWidth < 1600) this.sort.gridWeb = 3;
      if(this.window.innerWidth < 1350 && this.window.innerWidth > 1050) this.sort.gridWeb = 2;
      if(this.window.innerWidth < 1050) this.sort.gridWeb = 1;
  }
  searchByLetter(letter) {
      if(letter === this.sort.letterSearch) return this.sort.letterSearch = null;
      this.sort.letterSearch = letter;
  }
  ngOnInit() {
  }

}
